INSERT INTO pizzas (id, name, price, ingredients)
VALUES (1000, 'Pizza Margherita', 20.00, 'Sos pomidorowy, ser mozzarella'),
       (1001, 'Pizza Funghi', 23.00, 'Sos pomidorowy, ser mozzarella, pieczarki');